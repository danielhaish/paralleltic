from distutils.core import setup
from paralizethread import ParallelizeThread
setup(name='split-threads',
      version='1.0',
      description='Python Distribution Utilities',
      author='Greg Ward',
      author_email='gward@python.net',
      packages=['Paralai'],
     )